import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-found-component-component',
  templateUrl: './not-found-component-component.component.html',
  styleUrls: ['./not-found-component-component.component.css']
})
export class NotFoundComponentComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
