import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-customer-details',
  templateUrl: './create-customer-details.component.html',
  styleUrls: ['./create-customer-details.component.css']
})
export class CreateCustomerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
