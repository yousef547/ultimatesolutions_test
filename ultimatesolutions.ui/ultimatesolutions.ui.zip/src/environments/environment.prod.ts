export const environment = {
  production: true,
  url_api:"https://localhost:7281/api/"
};
